require("dotenv").config();
const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");

const PORT = process.env.PORT || 3001;
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5";

if (!process.env.ANTHROPIC_API_KEY) {
  console.error(
    "Missing ANTHROPIC_API_KEY. Copy backend/.env.example to backend/.env and add your key."
  );
  process.exit(1);
}

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const app = express();
app.use(cors());
app.use(express.json({ limit: "15mb" }));

const ALLOWED_MIME_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

const ANALYSIS_PROMPT = `You are a plant pathologist specializing in postharvest and orchard fruit disease diagnosis.
Examine the fruit in this image closely for signs of disease, fungal or bacterial infection, pest damage, rot, blemishes, or physiological disorders.

Respond with ONLY a raw JSON object, no markdown fences, no commentary, matching exactly this shape:

{
  "fruit_type": "string, best guess at the fruit species/variety, or 'Unknown' if unclear",
  "is_healthy": boolean,
  "condition_name": "string, common name of the disease/disorder found, or 'No disease detected' if healthy",
  "confidence": number from 0 to 100,
  "severity": "none" | "mild" | "moderate" | "severe",
  "symptoms": ["array of short strings describing visible symptoms observed"],
  "treatment": ["array of short strings, ordered, actionable treatment steps"],
  "prevention": ["array of short strings, practical prevention tips for future crops"],
  "notes": "string, 1-2 sentences of additional context or caveats, e.g. if the image quality limits certainty"
}

If the image does not appear to contain a fruit, set fruit_type to "Unknown", is_healthy to false, condition_name to "Not a fruit image", confidence to 0, severity to "none", and explain in notes.
Base your diagnosis only on visual evidence in the image. Be specific about symptom appearance (color, texture, pattern, location).`;

function extractJson(text) {
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) {
    throw new Error("Model response did not contain a JSON object");
  }
  return JSON.parse(cleaned.slice(start, end + 1));
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", model: MODEL });
});

app.post("/api/analyze", async (req, res) => {
  const { image, mimeType } = req.body || {};

  if (!image || typeof image !== "string") {
    return res.status(400).json({ error: "Request must include a base64 'image' string." });
  }
  if (!mimeType || !ALLOWED_MIME_TYPES.has(mimeType)) {
    return res.status(400).json({ error: "mimeType must be one of jpeg, png, webp, or gif." });
  }

  try {
    const message = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mimeType, data: image } },
            { type: "text", text: ANALYSIS_PROMPT },
          ],
        },
      ],
    });

    const textBlock = message.content.find((block) => block.type === "text");
    if (!textBlock) {
      return res.status(502).json({ error: "The model returned no analysis text." });
    }

    const diagnosis = extractJson(textBlock.text);
    res.json(diagnosis);
  } catch (err) {
    console.error("Analysis error:", err.message);
    if (err.status === 401) {
      return res.status(401).json({ error: "Invalid or missing Anthropic API key on the server." });
    }
    if (err.status === 429) {
      return res.status(429).json({ error: "Rate limit reached. Wait a moment and try again." });
    }
    res.status(500).json({ error: "Analysis failed. See server logs for details." });
  }
});

app.listen(PORT, () => {
  console.log(`Orchard Loupe backend listening on http://localhost:${PORT}`);
  console.log(`Using model: ${MODEL}`);
});
