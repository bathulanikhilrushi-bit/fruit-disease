import { useState, useRef, useCallback, useEffect } from "react";

const COLORS = {
  paper: "#F1F3EA",
  paperDim: "#E7EADD",
  ink: "#1B2A1D",
  inkSoft: "#4A5A46",
  leaf: "#3F6B33",
  leafDeep: "#2A4A22",
  teal: "#1C7C79",
  tealDeep: "#134F4D",
  amber: "#D98A2B",
  amberDeep: "#8A5613",
  red: "#B23A2E",
  redDeep: "#772620",
  line: "#C9CDB8",
};

const SEVERITY_META = {
  none: { label: "Healthy", color: COLORS.leaf, deep: COLORS.leafDeep, bg: "#E6EEDF" },
  mild: { label: "Mild", color: COLORS.amber, deep: COLORS.amberDeep, bg: "#FBEDD9" },
  moderate: { label: "Moderate", color: COLORS.amber, deep: COLORS.amberDeep, bg: "#FBEDD9" },
  severe: { label: "Severe", color: COLORS.red, deep: COLORS.redDeep, bg: "#F6DFDC" },
};

const API_BASE = import.meta.env.VITE_API_BASE_URL || "";

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

function useScanClock(active) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (!active) {
      setElapsed(0);
      return;
    }
    const start = Date.now();
    const id = setInterval(() => setElapsed(Date.now() - start), 83);
    return () => clearInterval(id);
  }, [active]);
  return elapsed;
}

export default function App() {
  const [imageData, setImageData] = useState(null);
  const [imageMime, setImageMime] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [history, setHistory] = useState([]);
  const [activeHistoryId, setActiveHistoryId] = useState(null);
  const fileInputRef = useRef(null);
  const scanMs = useScanClock(analyzing);

  const loadFile = useCallback(async (file) => {
    if (!file || !file.type.startsWith("image/")) {
      setError("That file doesn't look like an image. Try a JPG or PNG.");
      return;
    }
    setError(null);
    setResult(null);
    setActiveHistoryId(null);
    try {
      const base64 = await fileToBase64(file);
      setImageData(base64);
      setImageMime(file.type);
      setPreviewUrl(URL.createObjectURL(file));
    } catch (e) {
      setError("Couldn't load that file. Try another image.");
    }
  }, []);

  const onDrop = useCallback(
    (e) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer.files && e.dataTransfer.files[0];
      loadFile(file);
    },
    [loadFile]
  );

  const runDiagnostic = useCallback(async () => {
    if (!imageData) return;
    setAnalyzing(true);
    setError(null);
    setResult(null);
    try {
      const response = await fetch(`${API_BASE}/api/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: imageData, mimeType: imageMime }),
      });

      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error || "Analysis service returned an error");
      }

      setResult(payload);
      const entry = {
        id: Date.now() + Math.random(),
        thumb: previewUrl,
        result: payload,
        time: new Date(),
      };
      setHistory((h) => [entry, ...h].slice(0, 12));
      setActiveHistoryId(entry.id);
    } catch (e) {
      setError(e.message || "Diagnostic run failed. Check your connection and try again.");
    } finally {
      setAnalyzing(false);
    }
  }, [imageData, imageMime, previewUrl]);

  const openHistoryEntry = (entry) => {
    setResult(entry.result);
    setPreviewUrl(entry.thumb);
    setActiveHistoryId(entry.id);
    setError(null);
  };

  const reset = () => {
    setImageData(null);
    setImageMime(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
    setActiveHistoryId(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const severity = result ? SEVERITY_META[result.severity] || SEVERITY_META.mild : null;
  const scanSweepPct = analyzing ? Math.min(96, (scanMs / 2600) * 100) : 0;

  return (
    <div style={styles.page}>
      <style>{`
        .ol-root * { box-sizing: border-box; }
        .ol-drop:hover { border-color: ${COLORS.leaf} !important; }
        .ol-btn { cursor: pointer; transition: transform 0.12s ease, background 0.15s ease; }
        .ol-btn:active { transform: scale(0.97); }
        .ol-btn:disabled { cursor: not-allowed; opacity: 0.5; }
        .ol-hist-chip { cursor: pointer; transition: border-color 0.15s ease; }
        .ol-hist-chip:hover { border-color: ${COLORS.teal} !important; }
        @keyframes ol-fade-up {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .ol-field { animation: ol-fade-up 0.35s ease both; }
        @media (max-width: 760px) {
          .ol-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>

      <div className="ol-root" style={styles.root}>
        <header style={styles.header}>
          <div style={styles.brandRow}>
            <div style={styles.mark}>
              <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
                <circle cx="11" cy="11" r="8" stroke={COLORS.paper} strokeWidth="2" />
                <line x1="16.5" y1="16.5" x2="23" y2="23" stroke={COLORS.paper} strokeWidth="2.4" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <div style={styles.wordmark}>ORCHARD LOUPE</div>
              <div style={styles.tagline}>Field diagnostics for fruit, in seconds</div>
            </div>
          </div>
          <div style={styles.headerRight}>
            <span style={styles.pill}>CLOUD VISION · LIVE</span>
          </div>
        </header>

        <div className="ol-grid" style={styles.grid}>
          <section style={styles.panel}>
            <div style={styles.panelLabel}>SAMPLE</div>
            <div
              className="ol-drop"
              onClick={() => !previewUrl && fileInputRef.current && fileInputRef.current.click()}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              style={{
                ...styles.dropZone,
                borderColor: dragOver ? COLORS.leaf : COLORS.line,
                cursor: previewUrl ? "default" : "pointer",
                background: previewUrl ? COLORS.ink : COLORS.paperDim,
              }}
            >
              {previewUrl ? (
                <div style={styles.imageWrap}>
                  <img src={previewUrl} alt="Fruit sample" style={styles.image} />
                  {analyzing && (
                    <>
                      <div style={styles.scanGrid} />
                      <div style={{ ...styles.scanLine, top: `${scanSweepPct}%` }} />
                    </>
                  )}
                </div>
              ) : (
                <div style={styles.dropPrompt}>
                  <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke={COLORS.inkSoft} strokeWidth="1.4">
                    <path d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 9l5-5 5 5M12 4v13" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <div style={styles.dropText}>Drop a fruit photo here, or click to browse</div>
                  <div style={styles.dropSub}>JPG or PNG · one fruit per sample works best</div>
                </div>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={(e) => loadFile(e.target.files && e.target.files[0])}
            />

            <div style={styles.actionRow}>
              {previewUrl && (
                <button className="ol-btn" style={styles.ghostBtn} onClick={reset} disabled={analyzing}>
                  New sample
                </button>
              )}
              <button
                className="ol-btn"
                style={{ ...styles.primaryBtn, opacity: !imageData || analyzing ? 0.55 : 1 }}
                onClick={runDiagnostic}
                disabled={!imageData || analyzing}
              >
                {analyzing ? "Scanning\u2026" : "Run diagnostic"}
              </button>
            </div>

            {error && <div style={styles.errorBox}>{error}</div>}

            {history.length > 0 && (
              <div style={styles.historySection}>
                <div style={styles.panelLabel}>RECENT SAMPLES</div>
                <div style={styles.historyRow}>
                  {history.map((h) => {
                    const meta = SEVERITY_META[h.result.severity] || SEVERITY_META.mild;
                    return (
                      <div
                        key={h.id}
                        className="ol-hist-chip"
                        onClick={() => openHistoryEntry(h)}
                        style={{
                          ...styles.histChip,
                          borderColor: activeHistoryId === h.id ? COLORS.teal : COLORS.line,
                        }}
                      >
                        <img src={h.thumb} alt="" style={styles.histThumb} />
                        <span style={{ ...styles.histDot, background: meta.color }} />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </section>

          <section style={styles.panel}>
            <div style={styles.panelLabel}>DIAGNOSTIC REPORT</div>

            {!result && !analyzing && (
              <div style={styles.emptyReport}>
                <div style={styles.emptyGlyph}>&#8734;</div>
                <div style={styles.emptyTitle}>Load a sample to begin</div>
                <div style={styles.emptyBody}>
                  The report fills in here once a diagnostic finishes running &mdash; condition, confidence, and what to do about it.
                </div>
              </div>
            )}

            {analyzing && !result && (
              <div style={styles.emptyReport}>
                <div style={styles.scanningTicker}>
                  {"ANALYZING SAMPLE".split("").map((c, i) => (
                    <span key={i} style={{ animationDelay: `${i * 40}ms` }} className="ol-field">
                      {c}
                    </span>
                  ))}
                </div>
                <div style={styles.emptyBody}>Reading tissue color, lesion pattern, and surface texture.</div>
              </div>
            )}

            {result && severity && (
              <div style={styles.report}>
                <div className="ol-field" style={styles.reportRow}>
                  <span style={styles.fieldLabel}>FRUIT TYPE</span>
                  <span style={styles.fieldValue}>{result.fruit_type}</span>
                </div>

                <div className="ol-field" style={styles.statusRow}>
                  <span style={{ ...styles.statusBadge, background: severity.bg, color: severity.deep }}>
                    {severity.label}
                  </span>
                  <span style={styles.conditionName}>{result.condition_name}</span>
                </div>

                <div className="ol-field" style={styles.confidenceBlock}>
                  <div style={styles.reportRow}>
                    <span style={styles.fieldLabel}>CONFIDENCE</span>
                    <span style={styles.fieldValueMono}>{Math.round(result.confidence)}%</span>
                  </div>
                  <div style={styles.confidenceTrack}>
                    <div
                      style={{
                        ...styles.confidenceFill,
                        width: `${Math.max(2, Math.min(100, result.confidence))}%`,
                        background: severity.color,
                      }}
                    />
                  </div>
                </div>

                {result.symptoms && result.symptoms.length > 0 && (
                  <div className="ol-field" style={styles.reportBlock}>
                    <span style={styles.fieldLabel}>SYMPTOMS OBSERVED</span>
                    <ul style={styles.list}>
                      {result.symptoms.map((s, i) => (
                        <li key={i} style={styles.listItem}>
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {result.treatment && result.treatment.length > 0 && (
                  <div className="ol-field" style={styles.reportBlock}>
                    <span style={styles.fieldLabel}>TREATMENT STEPS</span>
                    <ol style={styles.orderedList}>
                      {result.treatment.map((s, i) => (
                        <li key={i} style={styles.listItem}>
                          {s}
                        </li>
                      ))}
                    </ol>
                  </div>
                )}

                {result.prevention && result.prevention.length > 0 && (
                  <div className="ol-field" style={styles.reportBlock}>
                    <span style={styles.fieldLabel}>PREVENTION</span>
                    <ul style={styles.list}>
                      {result.prevention.map((s, i) => (
                        <li key={i} style={styles.listItem}>
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {result.notes && (
                  <div className="ol-field" style={styles.notes}>
                    {result.notes}
                  </div>
                )}
              </div>
            )}
          </section>
        </div>

        <footer style={styles.footer}>
          Diagnostics are generated by cloud-based image analysis and are a starting point, not a substitute for a
          local agricultural extension office on high-value crops.
        </footer>
      </div>
    </div>
  );
}

const styles = {
  page: {
    background: COLORS.paper,
    minHeight: "100vh",
    padding: "0",
    fontFamily: "'Source Serif 4', Georgia, serif",
    color: COLORS.ink,
  },
  root: {
    maxWidth: 1040,
    margin: "0 auto",
    padding: "28px 24px 48px",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 28,
    flexWrap: "wrap",
    gap: 12,
  },
  brandRow: { display: "flex", alignItems: "center", gap: 12 },
  mark: {
    width: 40,
    height: 40,
    borderRadius: 10,
    background: COLORS.leafDeep,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  wordmark: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 700,
    fontSize: 20,
    letterSpacing: "0.02em",
    lineHeight: 1.1,
  },
  tagline: {
    fontSize: 13,
    color: COLORS.inkSoft,
    marginTop: 2,
  },
  headerRight: {},
  pill: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 11,
    letterSpacing: "0.08em",
    color: COLORS.tealDeep,
    background: "#DCEEEC",
    padding: "6px 10px",
    borderRadius: 20,
    border: `1px solid ${COLORS.teal}55`,
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)",
    gap: 20,
    alignItems: "start",
  },
  panel: {
    background: "#FFFFFF",
    border: `1px solid ${COLORS.line}`,
    borderRadius: 4,
    padding: 20,
  },
  panelLabel: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 11,
    letterSpacing: "0.12em",
    color: COLORS.inkSoft,
    marginBottom: 12,
    display: "block",
  },
  dropZone: {
    border: `1.5px dashed ${COLORS.line}`,
    borderRadius: 4,
    minHeight: 260,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    position: "relative",
  },
  dropPrompt: {
    textAlign: "center",
    padding: 24,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 8,
  },
  dropText: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 15,
    color: COLORS.ink,
  },
  dropSub: {
    fontSize: 12.5,
    color: COLORS.inkSoft,
    fontFamily: "'IBM Plex Mono', monospace",
    letterSpacing: "0.01em",
  },
  imageWrap: {
    position: "relative",
    width: "100%",
    height: 300,
  },
  image: {
    width: "100%",
    height: "100%",
    objectFit: "contain",
    display: "block",
  },
  scanGrid: {
    position: "absolute",
    inset: 0,
    backgroundImage: `linear-gradient(${COLORS.teal}22 1px, transparent 1px), linear-gradient(90deg, ${COLORS.teal}22 1px, transparent 1px)`,
    backgroundSize: "24px 24px",
    pointerEvents: "none",
  },
  scanLine: {
    position: "absolute",
    left: 0,
    right: 0,
    height: 2,
    background: COLORS.teal,
    boxShadow: `0 0 12px 3px ${COLORS.teal}aa`,
  },
  actionRow: {
    display: "flex",
    gap: 10,
    marginTop: 16,
    justifyContent: "flex-end",
  },
  primaryBtn: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 14,
    color: "#FFF",
    background: COLORS.leaf,
    border: "none",
    borderRadius: 4,
    padding: "11px 20px",
  },
  ghostBtn: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 14,
    color: COLORS.ink,
    background: "transparent",
    border: `1px solid ${COLORS.line}`,
    borderRadius: 4,
    padding: "11px 16px",
  },
  errorBox: {
    marginTop: 14,
    fontSize: 13.5,
    color: COLORS.redDeep,
    background: "#F6DFDC",
    border: `1px solid ${COLORS.red}55`,
    borderRadius: 4,
    padding: "10px 12px",
  },
  historySection: { marginTop: 22 },
  historyRow: { display: "flex", gap: 8, flexWrap: "wrap" },
  histChip: {
    position: "relative",
    width: 48,
    height: 48,
    borderRadius: 4,
    overflow: "hidden",
    border: `1.5px solid ${COLORS.line}`,
  },
  histThumb: { width: "100%", height: "100%", objectFit: "cover", display: "block" },
  histDot: {
    position: "absolute",
    bottom: 3,
    right: 3,
    width: 8,
    height: 8,
    borderRadius: "50%",
    border: "1.5px solid #fff",
  },
  emptyReport: {
    minHeight: 300,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    gap: 8,
    padding: 24,
  },
  emptyGlyph: { fontSize: 26, color: COLORS.line, fontFamily: "'Space Grotesk', sans-serif" },
  emptyTitle: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 15.5,
    color: COLORS.ink,
  },
  emptyBody: {
    fontSize: 13.5,
    color: COLORS.inkSoft,
    maxWidth: 280,
    lineHeight: 1.5,
  },
  scanningTicker: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 14,
    letterSpacing: "0.12em",
    color: COLORS.tealDeep,
  },
  report: { display: "flex", flexDirection: "column", gap: 16 },
  reportRow: { display: "flex", justifyContent: "space-between", alignItems: "baseline" },
  fieldLabel: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 11,
    letterSpacing: "0.1em",
    color: COLORS.inkSoft,
  },
  fieldValue: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 14,
    color: COLORS.ink,
  },
  fieldValueMono: {
    fontFamily: "'IBM Plex Mono', monospace",
    fontSize: 14,
    fontWeight: 500,
    color: COLORS.ink,
  },
  statusRow: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    paddingBottom: 14,
    borderBottom: `1px solid ${COLORS.line}`,
  },
  statusBadge: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 12.5,
    padding: "5px 12px",
    borderRadius: 20,
    letterSpacing: "0.02em",
  },
  conditionName: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 700,
    fontSize: 17,
    color: COLORS.ink,
  },
  confidenceBlock: { display: "flex", flexDirection: "column", gap: 6 },
  confidenceTrack: {
    height: 6,
    borderRadius: 3,
    background: COLORS.paperDim,
    overflow: "hidden",
  },
  confidenceFill: { height: "100%", borderRadius: 3 },
  reportBlock: { display: "flex", flexDirection: "column", gap: 6 },
  list: { margin: "4px 0 0", paddingLeft: 18 },
  orderedList: { margin: "4px 0 0", paddingLeft: 20 },
  listItem: { fontSize: 14, lineHeight: 1.55, marginBottom: 4, color: COLORS.ink },
  notes: {
    fontSize: 13,
    fontStyle: "italic",
    color: COLORS.inkSoft,
    borderLeft: `2px solid ${COLORS.line}`,
    paddingLeft: 12,
  },
  footer: {
    marginTop: 32,
    fontSize: 12,
    color: COLORS.inkSoft,
    textAlign: "center",
    lineHeight: 1.6,
  },
};
